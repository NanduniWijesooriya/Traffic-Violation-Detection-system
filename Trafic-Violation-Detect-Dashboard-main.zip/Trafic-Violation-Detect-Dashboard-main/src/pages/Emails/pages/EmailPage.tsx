const EmailPage = () => {
  return <div>EmailPage</div>;
};

export default EmailPage;
