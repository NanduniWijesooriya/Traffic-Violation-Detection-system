const PaymentPage = () => {
  return <div>PaymentPage</div>;
};

export default PaymentPage;
