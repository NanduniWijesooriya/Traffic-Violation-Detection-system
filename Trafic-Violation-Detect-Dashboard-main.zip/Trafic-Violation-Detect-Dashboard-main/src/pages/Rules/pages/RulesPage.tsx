import RuleCard from "../components/RuleCard";

const RulesPage = () => {
  return (
    <div className="w-full px-8">
      <RuleCard />
    </div>
  );
};

export default RulesPage;
