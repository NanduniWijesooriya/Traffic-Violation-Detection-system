import { useState } from "react";
import { MdReportProblem } from "react-icons/md";

const GenerateReport = () => {
  const [userEmail, setUserEmail] = useState<string>("");
  const sendEmailViaReportHandler = (e: React.FormEvent): void => {
    e.preventDefault();
    console.log(userEmail);
  };
  return (
    <div className="w-full rounded-sm min-h-[500px]">
      <div className="border p-4">
        <div className="flex items-center gap-2 mb-4">
          <MdReportProblem className="text-red-500" />
          <h1 className="text-lg text-red-600">Violation Report</h1>
        </div>

        <div className="w-full px-2">
          <div className="w-full flex items-center gap-6 mb-4">
            <h1 className="font-semibold text-sm text-gray-700">ID</h1>
            <p className="text-gray-600 text-xs">V1HTSX</p>
          </div>

          <div className="w-full flex items-center gap-6 mb-4">
            <h1 className="font-semibold text-sm text-gray-700">
              Vehicle Number
            </h1>
            <p className="text-gray-600 text-xs">NA - 2345</p>
          </div>

          <div className="w-full flex items-center gap-6 mb-4">
            <h1 className="font-semibold text-sm text-gray-700">Time & Date</h1>
            <p className="text-gray-600 text-xs">11.45AM | 2024-05-12</p>
          </div>

          <div className="w-full flex items-center gap-6 mb-4">
            <h1 className="font-semibold text-sm text-gray-700">Email</h1>
            <p className="text-gray-600 text-xs">Indrajith@test.com</p>
          </div>

          <div className="w-full flex items-center gap-6 mb-4">
            <h1 className="font-semibold text-sm text-gray-700">Address</h1>
            <p className="text-gray-600 text-xs">123, Kandy road, Kagalle</p>
          </div>

          <div className="w-full flex items-center gap-6 mb-4">
            <h1 className="font-semibold text-sm text-gray-700">Violation</h1>
            <p className="text-gray-600 text-xs">Illegal Parking</p>
          </div>

          <div className="w-full flex items-center gap-6 mb-4">
            <h1 className="font-semibold text-sm text-gray-700">Fine</h1>
            <p className="text-lg text-red-500 font text-xs-bold">
              RS. 34500.00
            </p>
          </div>

          <div className="mt-2 flex flex-col text-xs">
            <h1>Kandy Poince Station</h1>
            <h1>ploceKandy@gmail.com</h1>
            <h1>071 4578490</h1>
          </div>
        </div>
      </div>
      <div className="py-2">
        <form onSubmit={sendEmailViaReportHandler}>
          <div className="grid grid-cols-4 gap-2">
            <input
              type="email"
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setUserEmail(e.target.value)
              }
              className="p-2 col-span-3 text-sm w-full rounded-sm border border-gray-200"
              placeholder="Enter user email"
              required
            />
            <button className="text-white text-xs col-span-1 bg-blue-500 rounded-sm p-2">
              Send Report
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default GenerateReport;
